# Pile Detection > 2025-06-03 8:05pm
https://universe.roboflow.com/yolodatagen/pile-detection

Provided by a Roboflow user
License: CC BY 4.0

